
<div class="logo" style="font-family: 'Patua One', cursive;">
    <span>N</span>
    <span>E</span>
    <span>W</span>
    <span>S</span>
</div>
<?php /**PATH C:\xampp\htdocs\News\resources\views/components/application-logo.blade.php ENDPATH**/ ?>