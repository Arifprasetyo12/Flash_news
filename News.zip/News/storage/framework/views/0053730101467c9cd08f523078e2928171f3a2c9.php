<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Articles')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php
    $news_index = 0;
    ?>
    <div>
        <div class="flex mt-20 px-5 justify-around">
            <?php for($i = 0; $i < 3; $i++): ?>
                <?php if($news_index < count($news1)): ?>

            <div class="custom-card focus-div rounded-xl p-4"  style="margin-left: 8 px">
                <img src="<?php echo e($news1[$news_index]->thumbnail); ?>" style="width: 416px; height: 233px;">
                <h2 class="text-2xl mt-2 title-font"><a href="<?php echo e('readNews/' . $news1[$news_index]->id); ?>"><?php echo e($news1[$news_index]->title); ?></a></h2>
                <p class="mt-1 content-font">
                    <?php echo strlen(strip_tags($news1[$i]->content))>100?Str::substr(strip_tags($news1[$i]->content), 0, 100) . '...':strip_tags($news1[$i]->content); ?>

                </p>
                <h4 class="mt-2"><?php echo e($news1[$news_index]->author_name); ?></h4>
                <h4><?php echo e($news1[$news_index]->date_publish); ?></h4>
                <h4 class="pl-3 border-l-4 border-black mt-1"><?php echo e($news1[$news_index]->category); ?></h4>
            </div>
        <?php
            $news_index++;
        ?> <?php endif; ?> <?php endfor; ?>
        </div>


    <div class="mt-12 px-5">
        <?php for(; $news_index < count($news1); $news_index++): ?>

            <div class="flex mb-3 focus-div rounded-xl p-4">

                <img src="<?php echo e($news1[$news_index]->thumbnail); ?>" style="width: 208px;">
                <div class="pl-3">
                    <h2 class="text-2xl title-font"><a
                            href="<?php echo e('readNews/' . $news1[$news_index]->id); ?>"><?php echo e($news1[$news_index]->title); ?></a></h2>
                    <p class="content-font">
                    <?php echo strlen(strip_tags($news1[$i]->content))>300?Str::substr(strip_tags($news1[$i]->content), 0, 300) . '...':strip_tags($news1[$i]->content); ?>

                    </p>
                    <h4 class="mt-2"><?php echo e($news1[$news_index]->author_name); ?></h4>
                    <h4><?php echo e($news1[$news_index]->date_publish); ?></h4>
                    <h4 class="pl-3 border-l-4 border-black mt-1"><?php echo e($news1[$news_index]->category); ?></h4>
                </div>
            </div>
        <?php endfor; ?>
    </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\News\resources\views/manage/allnewsAdmin.blade.php ENDPATH**/ ?>