<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Manage Articles')); ?>

            <button type="button" class="btn btn-dark ml-4">
                <a style="color:white" href="add">Add New News</a>
            </button>
        </h2>
     <?php $__env->endSlot(); ?>


    <div>
        <div class="flex flex-wrap mt-20 px-5 justify-around">
            <?php for($i = 0; $i < count($news1); $i++): ?>


            <div class="custom-card focus-div rounded-xl p-4">
                <img src="<?php echo e($news1[$i]->thumbnail); ?>" style="width: 416px; height: 233px;">
                <h2 class="text-2xl mt-2 title-font"><a href="<?php echo e('read/' . $news1[$i]->id); ?>"><?php echo e($news1[$i]->title); ?></a></h2>
                <p class="mt-1 content-font">
                    <?php echo strlen(strip_tags($news1[$i]->content))>300?Str::substr(strip_tags($news1[$i]->content), 0, 300) . '...':strip_tags($news1[$i]->content); ?>

                </p>
                <h4 class="mt-2"><?php echo e($news1[$i]->author_name); ?></h4>
                <h4><?php echo e($news1[$i]->date_publish); ?></h4>
                <h4>number of visitors : <?php echo e($news1[$i]->number_visitors); ?></h4>
                <h4 class="pl-3 border-l-4 border-black mt-1"><?php echo e($news1[$i]->category); ?></h4>
                <div class="mt-2">
                    <button type="button" class="btn btn-dark"><a style="color:white"
                        href="<?php echo e('edit/' . $news1[$i]->id); ?>"> Edit </a></button>
                    <button type="button" class="btn btn-danger"><a style="color:white"
                        href="<?php echo e('add/' . $news1[$i]->id); ?>"> Delete </a></button>
                </div>
            </div>
        <?php endfor; ?>
        </div>
    </div>



 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\News\resources\views/manage/viewAdmin.blade.php ENDPATH**/ ?>