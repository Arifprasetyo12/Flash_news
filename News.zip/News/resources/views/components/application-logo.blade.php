
<div class="logo" style="font-family: 'Patua One', cursive;">
    <span>N</span>
    <span>E</span>
    <span>W</span>
    <span>S</span>
</div>
